<!DOCTYPE html>
<html>
<head>
<title>Payment</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">

<div class="container mt-5">
<div class="card p-5 shadow-lg">

<h2>Payment</h2>

<input type="text" class="form-control mb-3" placeholder="Card Number">
<input type="text" class="form-control mb-3" placeholder="UPI ID">

<a href="confirmation.jsp" class="btn btn-success">
Pay Now
</a>

</div>
</div>

</body>
</html>
