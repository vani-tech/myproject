<!DOCTYPE html>
<html>
<head>
<title>Theatres</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">

<div class="container mt-5">
<h2>Select Theatre</h2>

<div class="list-group mt-4">
<a href="seats.jsp" class="list-group-item list-group-item-action">
AMB Cinemas - Hyderabad
</a>

<a href="seats.jsp" class="list-group-item list-group-item-action">
Prasads Multiplex - Hyderabad
</a>

<a href="seats.jsp" class="list-group-item list-group-item-action">
PVR Cinemas - Vijayawada
</a>
</div>
</div>

</body>
</html>
