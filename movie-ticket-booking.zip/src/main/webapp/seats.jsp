<!DOCTYPE html>
<html>
<head>
<title>Seats</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-dark text-white">

<div class="container text-center mt-5">
<div class="screen">SCREEN</div>

<div class="mt-5">
<button class="seat">A1</button>
<button class="seat">A2</button>
<button class="seat booked">A3</button>
<button class="seat">A4</button>
</div>

<a href="payment.jsp" class="btn btn-success mt-5">
Proceed to Payment
</a>

</div>

</body>
</html>
