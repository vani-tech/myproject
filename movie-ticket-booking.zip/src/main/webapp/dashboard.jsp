<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<title>Movies</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<nav class="navbar navbar-dark bg-dark">
<div class="container-fluid">
<span class="navbar-brand mb-0 h1">Telugu Movie Booking</span>
</div>
</nav>

<div class="container mt-4">
<div class="row">

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Pushpa+2" class="card-img-top">
            <div class="card-body">
                <h5>Pushpa 2</h5>
                <a href="theatres.jsp?movie=Pushpa+2" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Kalki+2898+AD" class="card-img-top">
            <div class="card-body">
                <h5>Kalki 2898 AD</h5>
                <a href="theatres.jsp?movie=Kalki+2898+AD" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Salaar" class="card-img-top">
            <div class="card-body">
                <h5>Salaar</h5>
                <a href="theatres.jsp?movie=Salaar" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Devara" class="card-img-top">
            <div class="card-body">
                <h5>Devara</h5>
                <a href="theatres.jsp?movie=Devara" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=RRR" class="card-img-top">
            <div class="card-body">
                <h5>RRR</h5>
                <a href="theatres.jsp?movie=RRR" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=HanuMan" class="card-img-top">
            <div class="card-body">
                <h5>HanuMan</h5>
                <a href="theatres.jsp?movie=HanuMan" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Tillu+Square" class="card-img-top">
            <div class="card-body">
                <h5>Tillu Square</h5>
                <a href="theatres.jsp?movie=Tillu+Square" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Guntur+Kaaram" class="card-img-top">
            <div class="card-body">
                <h5>Guntur Kaaram</h5>
                <a href="theatres.jsp?movie=Guntur+Kaaram" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Hi+Nanna" class="card-img-top">
            <div class="card-body">
                <h5>Hi Nanna</h5>
                <a href="theatres.jsp?movie=Hi+Nanna" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Dasara" class="card-img-top">
            <div class="card-body">
                <h5>Dasara</h5>
                <a href="theatres.jsp?movie=Dasara" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=OG" class="card-img-top">
            <div class="card-body">
                <h5>OG</h5>
                <a href="theatres.jsp?movie=OG" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Game+Changer" class="card-img-top">
            <div class="card-body">
                <h5>Game Changer</h5>
                <a href="theatres.jsp?movie=Game+Changer" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Bro" class="card-img-top">
            <div class="card-body">
                <h5>Bro</h5>
                <a href="theatres.jsp?movie=Bro" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Adipurush" class="card-img-top">
            <div class="card-body">
                <h5>Adipurush</h5>
                <a href="theatres.jsp?movie=Adipurush" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Virupaksha" class="card-img-top">
            <div class="card-body">
                <h5>Virupaksha</h5>
                <a href="theatres.jsp?movie=Virupaksha" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Bheemla+Nayak" class="card-img-top">
            <div class="card-body">
                <h5>Bheemla Nayak</h5>
                <a href="theatres.jsp?movie=Bheemla+Nayak" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Sita+Ramam" class="card-img-top">
            <div class="card-body">
                <h5>Sita Ramam</h5>
                <a href="theatres.jsp?movie=Sita+Ramam" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Kushi" class="card-img-top">
            <div class="card-body">
                <h5>Kushi</h5>
                <a href="theatres.jsp?movie=Kushi" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Eagle" class="card-img-top">
            <div class="card-body">
                <h5>Eagle</h5>
                <a href="theatres.jsp?movie=Eagle" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Skanda" class="card-img-top">
            <div class="card-body">
                <h5>Skanda</h5>
                <a href="theatres.jsp?movie=Skanda" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Baby" class="card-img-top">
            <div class="card-body">
                <h5>Baby</h5>
                <a href="theatres.jsp?movie=Baby" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=DJ+Tillu" class="card-img-top">
            <div class="card-body">
                <h5>DJ Tillu</h5>
                <a href="theatres.jsp?movie=DJ+Tillu" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Rangasthalam" class="card-img-top">
            <div class="card-body">
                <h5>Rangasthalam</h5>
                <a href="theatres.jsp?movie=Rangasthalam" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Aravinda+Sametha" class="card-img-top">
            <div class="card-body">
                <h5>Aravinda Sametha</h5>
                <a href="theatres.jsp?movie=Aravinda+Sametha" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Ala+Vaikunthapurramuloo" class="card-img-top">
            <div class="card-body">
                <h5>Ala Vaikunthapurramuloo</h5>
                <a href="theatres.jsp?movie=Ala+Vaikunthapurramuloo" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Jersey" class="card-img-top">
            <div class="card-body">
                <h5>Jersey</h5>
                <a href="theatres.jsp?movie=Jersey" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Majili" class="card-img-top">
            <div class="card-body">
                <h5>Majili</h5>
                <a href="theatres.jsp?movie=Majili" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Sarileru+Neekevvaru" class="card-img-top">
            <div class="card-body">
                <h5>Sarileru Neekevvaru</h5>
                <a href="theatres.jsp?movie=Sarileru+Neekevvaru" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Waltair+Veerayya" class="card-img-top">
            <div class="card-body">
                <h5>Waltair Veerayya</h5>
                <a href="theatres.jsp?movie=Waltair+Veerayya" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Veera+Simha+Reddy" class="card-img-top">
            <div class="card-body">
                <h5>Veera Simha Reddy</h5>
                <a href="theatres.jsp?movie=Veera+Simha+Reddy" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Acharya" class="card-img-top">
            <div class="card-body">
                <h5>Acharya</h5>
                <a href="theatres.jsp?movie=Acharya" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Radhe+Shyam" class="card-img-top">
            <div class="card-body">
                <h5>Radhe Shyam</h5>
                <a href="theatres.jsp?movie=Radhe+Shyam" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Yevadu" class="card-img-top">
            <div class="card-body">
                <h5>Yevadu</h5>
                <a href="theatres.jsp?movie=Yevadu" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Race+Gurram" class="card-img-top">
            <div class="card-body">
                <h5>Race Gurram</h5>
                <a href="theatres.jsp?movie=Race+Gurram" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Temper" class="card-img-top">
            <div class="card-body">
                <h5>Temper</h5>
                <a href="theatres.jsp?movie=Temper" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=iSmart+Shankar" class="card-img-top">
            <div class="card-body">
                <h5>iSmart Shankar</h5>
                <a href="theatres.jsp?movie=iSmart+Shankar" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Krack" class="card-img-top">
            <div class="card-body">
                <h5>Krack</h5>
                <a href="theatres.jsp?movie=Krack" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Robinhood" class="card-img-top">
            <div class="card-body">
                <h5>Robinhood</h5>
                <a href="theatres.jsp?movie=Robinhood" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Double+iSmart" class="card-img-top">
            <div class="card-body">
                <h5>Double iSmart</h5>
                <a href="theatres.jsp?movie=Double+iSmart" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Hari+Hara+Veera+Mallu" class="card-img-top">
            <div class="card-body">
                <h5>Hari Hara Veera Mallu</h5>
                <a href="theatres.jsp?movie=Hari+Hara+Veera+Mallu" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Kingdom" class="card-img-top">
            <div class="card-body">
                <h5>Kingdom</h5>
                <a href="theatres.jsp?movie=Kingdom" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Bhairavam" class="card-img-top">
            <div class="card-body">
                <h5>Bhairavam</h5>
                <a href="theatres.jsp?movie=Bhairavam" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Court" class="card-img-top">
            <div class="card-body">
                <h5>Court</h5>
                <a href="theatres.jsp?movie=Court" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=MAD+Square" class="card-img-top">
            <div class="card-body">
                <h5>MAD Square</h5>
                <a href="theatres.jsp?movie=MAD+Square" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Lucky+Baskhar" class="card-img-top">
            <div class="card-body">
                <h5>Lucky Baskhar</h5>
                <a href="theatres.jsp?movie=Lucky+Baskhar" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Mechanic+Rocky" class="card-img-top">
            <div class="card-body">
                <h5>Mechanic Rocky</h5>
                <a href="theatres.jsp?movie=Mechanic+Rocky" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Gaami" class="card-img-top">
            <div class="card-body">
                <h5>Gaami</h5>
                <a href="theatres.jsp?movie=Gaami" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Family+Star" class="card-img-top">
            <div class="card-body">
                <h5>Family Star</h5>
                <a href="theatres.jsp?movie=Family+Star" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-4">
        <div class="card movie-card bg-dark text-white">
            <img src="https://via.placeholder.com/300x400?text=Bhagavanth+Kesari" class="card-img-top">
            <div class="card-body">
                <h5>Bhagavanth Kesari</h5>
                <a href="theatres.jsp?movie=Bhagavanth+Kesari" class="btn btn-danger w-100">
                    Book Tickets
                </a>
            </div>
        </div>
    </div>

</div>
</div>

</body>
</html>
