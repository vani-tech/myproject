<!DOCTYPE html>
<html>
<head>
<title>Confirmation</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">

<div class="container text-center mt-5">
<h1 class="text-success">Booking Successful</h1>
<h3>Your Ticket is Confirmed</h3>
</div>

</body>
</html>
