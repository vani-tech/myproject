<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body class="login-body">

<div class="login-box">
<h2 class="text-center mb-4">Movie Booking Login</h2>

<form action="login" method="post">
<input type="text" name="username" class="form-control mb-3" placeholder="Username">
<input type="password" name="password" class="form-control mb-3" placeholder="Password">

<button class="btn btn-danger w-100">Login</button>
</form>

</div>

</body>
</html>
